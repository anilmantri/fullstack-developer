var message:string="Hello To All Welcome to Type Script"
console.log(message);